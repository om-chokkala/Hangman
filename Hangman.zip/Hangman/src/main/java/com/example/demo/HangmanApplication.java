package com.example.demo;

import com.example.demo.Business.CountryService;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HangmanApplication {

	public static void main(String[] args) {
		SpringApplication.run(HangmanApplication.class, args);
		/*CountryRepository countryRepository= new CountryRepository();
		String s= countryRepository.toString();
		System.out.println(s);*/

	}



}

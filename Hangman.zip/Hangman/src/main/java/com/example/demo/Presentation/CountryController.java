package com.example.demo.Presentation;

import com.example.demo.Business.Country;
import com.example.demo.Business.CountryService;
import com.example.demo.Repository.CountryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import javax.servlet.http.HttpSession;

@Controller
public class CountryController {

    @Autowired
    CountryService service;


   @GetMapping("/")
    public String country(Model model,HttpSession session){

 /*      char[] sessionCharGet =(char[]) session.getAttribute("sessionChar");
       if(sessionCharGet == null)
       {
           sessionCharGet= new char[service.randomCountryRepresentation().length];
       }
       session.setAttribute("sessionChar",sessionCharGet);*/
       model.addAttribute("randomCountry",service.randomCountry());
       model.addAttribute("countryName",service.randomCountryRepresentation());
       return "country";
   }

  @PostMapping("/")
    public String countryPost(Model model, @RequestParam String inputChar, HttpSession session){
      /* char[] sessionCharPost =(char[]) session.getAttribute("sessionChar");
       sessionCharPost=service.currentClue(inputChar);
       session.setAttribute("sessionChar",sessionCharPost);*/
       model.addAttribute("compareChar",service.currentClue(inputChar));
       return "country";
   }

 /*   @PostMapping("/")
    public String countryPost(Model model, @RequestParam String inputChar){
       model.addAttribute("compareChar",service.currentClue(inputChar));
       return "country";
   }*/
}
